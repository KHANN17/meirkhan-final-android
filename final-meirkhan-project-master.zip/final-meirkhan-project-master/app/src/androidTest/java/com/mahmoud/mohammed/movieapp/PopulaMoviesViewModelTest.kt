package com.mahmoud.mohammed.movieapp

import androidx.test.runner.AndroidJUnit4
import org.junit.runner.RunWith

@Suppress("UNCHECKED_CAST")
@RunWith(AndroidJUnit4::class)

class PopulaMoviesViewModelTest {

}