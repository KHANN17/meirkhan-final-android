package com.mahmoud.mohammed.movieapp.dagger.popular

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class PopularScope
