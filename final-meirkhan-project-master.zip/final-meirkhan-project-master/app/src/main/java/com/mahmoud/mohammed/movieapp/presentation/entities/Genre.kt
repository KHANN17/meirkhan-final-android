package com.mahmoud.mohammed.movieapp.presentation.entities

data class Genre(
        var id: Int = -1,
        var name: String? = null
)