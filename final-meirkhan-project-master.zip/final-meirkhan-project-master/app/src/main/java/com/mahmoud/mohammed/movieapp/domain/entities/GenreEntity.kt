package com.mahmoud.mohammed.movieapp.domain.entities

data class GenreEntity(
        var id: Int,
        var name: String
)