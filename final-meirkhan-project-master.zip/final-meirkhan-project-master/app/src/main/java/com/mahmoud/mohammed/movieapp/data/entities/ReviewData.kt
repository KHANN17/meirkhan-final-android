package com.mahmoud.mohammed.movieapp.data.entities
data class ReviewData(
        var id: String,
        var author: String,
        var content: String? = null
)