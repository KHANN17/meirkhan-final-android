package com.mahmoud.mohammed.movieapp.dagger.details

import javax.inject.Scope

@Scope
@kotlin.annotation.Retention(AnnotationRetention.RUNTIME)
annotation class DetailsScope