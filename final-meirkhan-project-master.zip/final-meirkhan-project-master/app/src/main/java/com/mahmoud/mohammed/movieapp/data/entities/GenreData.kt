package com.mahmoud.mohammed.movieapp.data.entities

data class GenreData(
        var id: Int,
        var name: String
)