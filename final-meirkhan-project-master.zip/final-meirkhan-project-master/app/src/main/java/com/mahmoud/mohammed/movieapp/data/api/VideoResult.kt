package com.mahmoud.mohammed.movieapp.data.api

import com.mahmoud.mohammed.movieapp.data.entities.VideoData
class VideoResult {

    var results: List<VideoData>? = null

}